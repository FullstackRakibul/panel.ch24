<template>
  <div>
    <footer class="bg-gray-200 dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700">
      <div class="max-w-8xl mx-auto px-4 py-2 sm:px-6 lg:px-8">
        <div class="flex items center justify-between">
          <div class="text-sm text-gray-800 dark:text-gray-400">
            &copy; 2025 Channel 24. All rights reserved.
          </div>
          <div class="flex space-x-4">
            <a href="#" class="text-gray-800 hover:text-gray-700 dark:hover:text-gray-300">
              Privacy Policy
            </a>
            <a href="#" class="text-gray-800 hover:text-gray-700 dark:hover:text-gray-300">
              Terms of Service
            </a>
            <a href="#" class="text-gray-800 hover:text-gray-700 dark:hover:text-gray-300">
              Contact Us
            </a>
          </div>
          <div class="text-sm text-gray-800 dark:text-gray-400">
            Version 1.0.0
          </div>
          <div class="flex items-center space-x-2">
            <a href="#" class="text-white hover:text-gray-700 dark:hover:text-gray-300">
              <svg class="h-5 w-5" fill="currentColor" viewBox="0 0 20 20">
                <path
                  d="M18.3 4.3a1.7 1.7 0 00-2.4 0l-8.6 8.6a1.7 1.7 0 002.4 2.4l8.6-8.6a1.7 1.7 0 000-2.4zM3.4 16.6a1.7 1.7 0 002.4 0l8.6-8.6a1.7 1.7 0 00-2.4-2.4l-8.6 8.6a1.7 1.7 0 000 2.4z" />
              </svg>
            </a>
            <a href="#" class="text-white hover:text-gray-700 dark:hover:text-gray-300">
              <svg class="h-5 w-5" fill="currentColor" viewBox="0 0 20 20">
                <path d="M10 2a8 8 0 100 16 8 8 0 000-16zm1.5 11.5H8.5v-1h3v1zm0-2.5H8.5V7h3v4z" />
              </svg>
            </a>
            <a href="#" class="text-white hover:text-gray-700 dark:hover:text-gray-300">
              <svg class="h-5 w-5" fill="currentColor" viewBox="0 0 20 20">
                <path d="M10 2a8 8 0 100 16 8 8 0 000-16zm1.5 11.5H8.5v-1h3v1zm0-2.5H8.5V7h3v4z" />
              </svg>
            </a>
          </div>
        </div>
      </div>
    </footer>
  </div>
</template>