<template>
  <h2>Home</h2>
  <a-button danger type="primary">Primary Button</a-button>
</template>
